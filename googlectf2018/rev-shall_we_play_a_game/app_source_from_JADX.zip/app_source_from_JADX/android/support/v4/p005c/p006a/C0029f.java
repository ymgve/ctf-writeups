package android.support.v4.p005c.p006a;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff.Mode;

public interface C0029f {
    void setTint(int i);

    void setTintList(ColorStateList colorStateList);

    void setTintMode(Mode mode);
}
