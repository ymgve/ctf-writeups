package android.support.v4.p005c.p006a;

import android.graphics.drawable.Drawable;

public interface C0180b {
    Drawable mo83a();

    void mo84a(Drawable drawable);
}
