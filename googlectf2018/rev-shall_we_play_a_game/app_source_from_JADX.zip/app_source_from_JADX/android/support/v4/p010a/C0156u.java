package android.support.v4.p010a;

import android.os.Bundle;
import android.support.v4.p009b.C0172b;

public abstract class C0156u {

    public interface C0155a<D> {
        C0172b<D> m819a(int i, Bundle bundle);

        void m820a(C0172b<D> c0172b);

        void m821a(C0172b<D> c0172b, D d);
    }

    public boolean mo66a() {
        return false;
    }
}
