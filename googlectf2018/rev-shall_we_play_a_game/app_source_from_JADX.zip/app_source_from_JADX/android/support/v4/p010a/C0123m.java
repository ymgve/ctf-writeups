package android.support.v4.p010a;

import android.content.Context;
import android.os.Bundle;
import android.view.View;
import java.io.FileDescriptor;
import java.io.PrintWriter;
import java.util.List;

public abstract class C0123m {

    public static abstract class C0121a {
        public void m617a(C0123m c0123m, C0114h c0114h) {
        }

        public void m618a(C0123m c0123m, C0114h c0114h, Context context) {
        }

        public void m619a(C0123m c0123m, C0114h c0114h, Bundle bundle) {
        }

        public void m620a(C0123m c0123m, C0114h c0114h, View view, Bundle bundle) {
        }

        public void m621b(C0123m c0123m, C0114h c0114h) {
        }

        public void m622b(C0123m c0123m, C0114h c0114h, Context context) {
        }

        public void m623b(C0123m c0123m, C0114h c0114h, Bundle bundle) {
        }

        public void m624c(C0123m c0123m, C0114h c0114h) {
        }

        public void m625c(C0123m c0123m, C0114h c0114h, Bundle bundle) {
        }

        public void m626d(C0123m c0123m, C0114h c0114h) {
        }

        public void m627d(C0123m c0123m, C0114h c0114h, Bundle bundle) {
        }

        public void m628e(C0123m c0123m, C0114h c0114h) {
        }

        public void m629f(C0123m c0123m, C0114h c0114h) {
        }

        public void m630g(C0123m c0123m, C0114h c0114h) {
        }
    }

    public interface C0122b {
        void m631a();
    }

    public abstract void mo62a(String str, FileDescriptor fileDescriptor, PrintWriter printWriter, String[] strArr);

    public abstract boolean mo63a();

    public abstract List<C0114h> mo64b();

    public abstract boolean mo65c();
}
