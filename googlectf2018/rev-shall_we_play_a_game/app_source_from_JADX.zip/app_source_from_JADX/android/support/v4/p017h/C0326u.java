package android.support.v4.p017h;

import android.view.View;

public interface C0326u {
    void mo343a(View view);
}
