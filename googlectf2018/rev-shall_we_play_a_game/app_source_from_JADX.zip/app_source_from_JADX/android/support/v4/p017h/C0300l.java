package android.support.v4.p017h;

import android.view.View;

public interface C0300l extends C0299k {
    void m1317a(View view, int i);

    void m1318a(View view, int i, int i2, int i3, int i4, int i5);

    void m1319a(View view, int i, int i2, int[] iArr, int i3);

    boolean m1320a(View view, View view2, int i, int i2);

    void m1321b(View view, View view2, int i, int i2);
}
