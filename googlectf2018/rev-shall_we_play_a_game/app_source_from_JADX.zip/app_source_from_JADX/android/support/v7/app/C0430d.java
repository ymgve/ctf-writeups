package android.support.v7.app;

import android.support.v7.view.C0479b;
import android.support.v7.view.C0479b.C0462a;

public interface C0430d {
    C0479b mo260a(C0462a c0462a);

    void mo261a(C0479b c0479b);

    void mo262b(C0479b c0479b);
}
