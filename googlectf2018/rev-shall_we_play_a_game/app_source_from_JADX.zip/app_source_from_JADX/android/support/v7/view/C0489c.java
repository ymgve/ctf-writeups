package android.support.v7.view;

public interface C0489c {
    void mo430a();

    void mo431b();
}
