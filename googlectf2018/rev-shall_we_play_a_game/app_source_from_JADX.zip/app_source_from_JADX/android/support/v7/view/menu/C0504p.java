package android.support.v7.view.menu;

public interface C0504p {

    public interface C0501a {
        void mo372a(C0524j c0524j, int i);

        boolean mo373a();

        C0524j getItemData();
    }

    void mo377a(C0521h c0521h);
}
