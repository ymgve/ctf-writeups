package android.support.v7.widget;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.p017h.C0324r;
import android.support.v7.view.menu.C0506o.C0459a;
import android.support.v7.view.menu.C0521h.C0442a;
import android.view.Menu;
import android.view.ViewGroup;
import android.view.Window.Callback;

public interface ad {
    C0324r mo497a(int i, long j);

    ViewGroup mo498a();

    void mo499a(int i);

    void mo500a(Drawable drawable);

    void mo501a(C0459a c0459a, C0442a c0442a);

    void mo502a(ap apVar);

    void mo503a(Menu menu, C0459a c0459a);

    void mo504a(Callback callback);

    void mo505a(CharSequence charSequence);

    void mo506a(boolean z);

    Context mo507b();

    void mo508b(int i);

    void mo509b(boolean z);

    void mo510c(int i);

    boolean mo511c();

    void mo512d();

    void mo513d(int i);

    CharSequence mo514e();

    void mo515f();

    void mo516g();

    boolean mo517h();

    boolean mo518i();

    boolean mo519j();

    boolean mo520k();

    boolean mo521l();

    void mo522m();

    void mo523n();

    int mo524o();

    int mo525p();

    Menu mo526q();
}
