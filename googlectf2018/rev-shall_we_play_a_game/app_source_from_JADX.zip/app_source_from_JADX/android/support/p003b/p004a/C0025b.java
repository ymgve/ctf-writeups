package android.support.p003b.p004a;

import android.graphics.drawable.Animatable;

public interface C0025b extends Animatable {
}
